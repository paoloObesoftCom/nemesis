#ifndef READER_THREAD_HPP_
#define READER_THREAD_HPP_

void* reader_thread(void *arg);

#endif
