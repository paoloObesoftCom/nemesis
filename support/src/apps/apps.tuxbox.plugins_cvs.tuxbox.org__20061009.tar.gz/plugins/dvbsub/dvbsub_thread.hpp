#ifndef DVBSUB_THREAD_HPP_
#define DVBSUB_THREAD_HPP_

#include <inttypes.h>

void* dvbsub_thread(void* arg);

#endif
