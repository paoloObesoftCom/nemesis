
#define	YELLOW			4
#define	GREEN			5
#define	BLUE			7
#define	STEELBLUE		6
#define	GRAY			8
#define	DARK			9
#define	MAGENTA			10
#define	CYAN			11
#define	BROWN			12
#define	AIR				13
#define	DACH			14
#define	ORANGE			15
#define	SAIR			16
