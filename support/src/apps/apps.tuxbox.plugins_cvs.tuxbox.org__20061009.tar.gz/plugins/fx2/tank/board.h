#ifndef TANK_H
#define TANK_H

extern	void	TankInitialize( void );
extern	void	Play( void );

#endif
