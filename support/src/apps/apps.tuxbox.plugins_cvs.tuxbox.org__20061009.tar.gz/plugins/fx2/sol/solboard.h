#ifndef MAZE_H
#define MAZE_H

extern	void	DrawBoard();
extern	void	BoardInitialize( void );
extern	void	MoveMouse( void );
extern	void	DrawScore( void );

#endif
