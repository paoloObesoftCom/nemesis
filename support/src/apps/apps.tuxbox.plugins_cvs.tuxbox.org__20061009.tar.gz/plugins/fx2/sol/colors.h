/**
 * defines some colors used in pics.h
 */

#ifndef COLORS_H
#define COLORS_H

#define	YELLOW			4
#define	GREEN			5
#define	STEELBLUE		6
#define	BLUE			7
#define	GRAY			8
#define	DARK			9
#define ORANGE                  10

#endif
