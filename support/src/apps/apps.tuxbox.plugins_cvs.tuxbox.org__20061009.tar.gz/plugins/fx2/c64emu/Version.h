/*
 *  Version.h - Version information
 *
 *  Frodo (C) 1994-1997 Christian Bauer
 */

#ifndef _VERSION_H
#define _VERSION_H

// Version/revision
const int FRODO_VERSION = 4;
const int FRODO_REVISION = 1;
const char VERSION_STRING[] = "Frodo V4.1a";

#endif
