/*
 *  SAM.h - Simple Assembler and Monitor With Integrated System Explorer
 *
 *  Frodo (C) 1994-1997 Christian Bauer
 */

#ifndef _SAM_H
#define _SAM_H

class C64;

// Exported functions
extern void SAM(C64 *the_c64);

#endif
