#ifndef MAZE_H
#define MAZE_H

extern	void	MasterInitialize( void );
extern	void	Play( void );

#endif
