
#define	YELLOW			4
#define	GREEN			5
#define	BLUE			7
#define	STEELBLUE		6
#define	GRAY			8
#define	DARK			9
#define	MAGENTA			10
#define	CYAN			11
