#ifndef __COLORS_H__
#define __COLORS_H__


#define COL_TABLE		1

#define COL_BLACK		2
#define COL_WHITE		3
#define COL_RED			4



#endif //__COLORS_H__

