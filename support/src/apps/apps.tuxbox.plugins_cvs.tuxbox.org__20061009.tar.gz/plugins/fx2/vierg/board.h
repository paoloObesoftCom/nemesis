#ifndef MAZE_H
#define MAZE_H

extern	void	DrawBoard( int rbomb );
extern	void	BoardInitialize( void );
extern	void	MoveMouse( void );

#endif
