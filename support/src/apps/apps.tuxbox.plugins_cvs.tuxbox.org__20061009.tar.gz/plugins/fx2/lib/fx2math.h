#ifndef FX2_MATH
#define FX2_MATH

extern	int	_atoi( const char *str );

#endif
