#ifndef SNAKE_H
#define SNAKE_H

extern	void	DrawMaze( void );
extern	void	MoveSnake( void );
extern	void	DrawGameOver( void );
extern	void	DrawFinalScore( void );
extern	void	FreeSnake( void );

#endif
