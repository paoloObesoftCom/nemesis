
#define	YELLOW			4
#define	GREEN			5
#define	STEELBLUE		6
#define	BLUE			7
#define	GRAY			8
#define	GRAY2			9
