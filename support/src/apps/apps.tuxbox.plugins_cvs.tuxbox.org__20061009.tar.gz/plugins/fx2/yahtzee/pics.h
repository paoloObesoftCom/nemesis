#ifndef PICS_H
#define PICS_H

#define MAZEW	44
#define	MAZEH	36

#define _	WHITE
#define W	BLUE

static unsigned char	point[] = {
_,W,W,W,W,W,_,
_,W,W,W,W,W,_,
W,W,W,W,W,W,W,
W,W,W,W,W,W,W,
W,W,W,W,W,W,W,
_,W,W,W,W,W,_,
_,W,W,W,W,W,_ };

#undef W
#undef _

#endif
