#ifndef YAHTZEE_H
#define YAHTZEE_H

extern	void	EnterPlayer( void );
extern	void	RunYahtzee( void );
extern	void	DrawWinner( void );

#endif
