#ifndef MAZE_H
#define MAZE_H

extern	void	DrawBoard( void );
extern	void	BoardInitialize( void );
extern	void	DrawGameOver( void );
extern	void	DrawScore( void );
extern  void    Startbildschirm( void );

extern int level;
extern int max_level;
#endif
