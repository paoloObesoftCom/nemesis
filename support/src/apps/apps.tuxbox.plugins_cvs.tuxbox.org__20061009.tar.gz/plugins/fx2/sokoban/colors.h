#define BLACK			1
#define WHITE			2
#define R			3
#define G			6
#define	B			4
#define GRAY			5
